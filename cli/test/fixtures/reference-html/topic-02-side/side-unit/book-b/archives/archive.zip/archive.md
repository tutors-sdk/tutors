# Objectives

A few sentences on the purpose of the lab - perhaps indicate objectives, duration or purpose.